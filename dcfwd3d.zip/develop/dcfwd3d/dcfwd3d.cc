#include <deal.II/base/function.h>
#include <deal.II/base/quadrature_lib.h>

#include <deal.II/dofs/dof_handler.h>
#include <deal.II/dofs/dof_tools.h>

#include <deal.II/fe/fe_q.h>
#include <deal.II/fe/fe_values.h>

#include <deal.II/grid/grid_generator.h>
#include <deal.II/grid/tria.h>

#include <deal.II/lac/dynamic_sparsity_pattern.h>
#include <deal.II/lac/full_matrix.h>
#include <deal.II/lac/precondition.h>
#include <deal.II/lac/solver_cg.h>
#include <deal.II/lac/sparse_matrix.h>
#include <deal.II/lac/vector.h>

#include <deal.II/numerics/data_out.h>
#include <deal.II/numerics/matrix_tools.h>
#include <deal.II/numerics/vector_tools.h>

#include <fstream>
#include <numeric>

class DCProblem {
public:
  DCProblem();

  void run();

private:
  void make_grid();
  void setup_system();
  void assemble_system();
  void solve();
  void output_results() const;

  void make_halfspace_model();
  void make_block_model();

  std::vector<double> rho;

  dealii::Triangulation<3> triangulation;
  dealii::FE_Q<3> fe;
  dealii::DoFHandler<3> dof_handler;

  dealii::SparsityPattern sparsity_pattern;
  dealii::SparseMatrix<double> system_matrix;

  dealii::Vector<double> solution;
  dealii::Vector<double> system_rhs;
};

DCProblem::DCProblem() : fe(1), dof_handler(triangulation) {}

void DCProblem::make_halfspace_model() {
  std::vector<double> dx{150, 120, 100, 70, 50, 50, 50, 50, 70, 100, 120, 150};
  std::vector<double> dy{150, 120, 100, 70, 50, 50, 50, 50, 70, 100, 120, 150};
  std::vector<double> dz{50, 50, 50, 50, 70, 100, 120, 150};

  double xstart = -std::accumulate(dx.begin(), dx.end(), 0) / 2.0;
  double ystart = -std::accumulate(dy.begin(), dy.end(), 0) / 2.0;
  double zend = std::accumulate(dz.begin(), dz.end(), 0);

  dealii::GridGenerator::subdivided_hyper_rectangle(triangulation, { dx, dy, dz }, dealii::Point<3>(xstart, ystart, 0),
                                                    dealii::Point<3>(-xstart, -ystart, zend));

  for (auto cell: triangulation.active_cell_iterators()) {
    cell->set_material_id(0);
  }

  triangulation.refine_global(2);

  rho = {100};
}

void DCProblem::make_block_model() {
  std::vector<double> dx{150, 120, 100, 70, 50, 50, 50, 50, 70, 100, 120, 150};
  std::vector<double> dy{150, 120, 100, 70, 50, 50, 50, 50, 70, 100, 120, 150};
  std::vector<double> dz{50, 50, 50, 50, 70, 100, 120, 150};

  double xstart = -std::accumulate(dx.begin(), dx.end(), 0) / 2.0;
  double ystart = -std::accumulate(dy.begin(), dy.end(), 0) / 2.0;
  double zend = std::accumulate(dz.begin(), dz.end(), 0);

  dealii::GridGenerator::subdivided_hyper_rectangle(triangulation, { dx, dy, dz }, dealii::Point<3>(xstart, ystart, 0),
                                                    dealii::Point<3>(-xstart, -ystart, zend));

  for (auto cell: triangulation.active_cell_iterators()) {
    auto center = cell->center();
    if (center[0] > -50 && center[0] < 50 && center[1] > -50 && center[1] < 50 && center[2] > 50 && center[2] < 150) {
      cell->set_material_id(1);
    } else {
      cell->set_material_id(0);
    }
  }

  triangulation.refine_global(2);

  rho = {100, 1};
}

void DCProblem::make_grid() {
  make_halfspace_model();
  // make_block_model();

  std::cout << "Number of active cells: " << triangulation.n_active_cells() << std::endl;
}

void DCProblem::setup_system() {
  dof_handler.distribute_dofs(fe);
  std::cout << "Number of degrees of freedom: " << dof_handler.n_dofs() << std::endl;

  dealii::DynamicSparsityPattern dsp(dof_handler.n_dofs());
  dealii::DoFTools::make_sparsity_pattern(dof_handler, dsp);
  sparsity_pattern.copy_from(dsp);

  system_matrix.reinit(sparsity_pattern);

  solution.reinit(dof_handler.n_dofs());
  system_rhs.reinit(dof_handler.n_dofs());
}

void DCProblem::assemble_system() {
  dealii::QGauss<3> quadrature_formula(fe.degree + 1);
  dealii::FEValues<3> fe_values(fe, quadrature_formula,
                                dealii::update_values | dealii::update_gradients | dealii::update_JxW_values);

  dealii::QGauss<2> face_quadrature_formula(fe.degree + 1);
  dealii::FEFaceValues<3> fe_face_values(fe, face_quadrature_formula,
                                         dealii::update_values | dealii::update_quadrature_points |
                                             dealii::update_normal_vectors | dealii::update_JxW_values);

  const unsigned int dofs_per_cell = fe.n_dofs_per_cell();

  dealii::FullMatrix<double> cell_matrix(dofs_per_cell, dofs_per_cell);

  std::vector<dealii::types::global_dof_index> local_dof_indices(dofs_per_cell);

  dealii::Point<3> source(0, 0, 0);

  for (const auto &cell : dof_handler.active_cell_iterators()) {
    double sigma = 1.0 / rho[cell->material_id()];

    fe_values.reinit(cell);

    cell_matrix = 0;
    for (const unsigned int q_index : fe_values.quadrature_point_indices()) {
      for (const unsigned int i : fe_values.dof_indices())
        for (const unsigned int j : fe_values.dof_indices())
          cell_matrix(i, j) += sigma * (fe_values.shape_grad(i, q_index) * // grad phi_i(x_q)
                                        fe_values.shape_grad(j, q_index) * // grad phi_j(x_q)
                                        fe_values.JxW(q_index));           // dx
    }
    cell->get_dof_indices(local_dof_indices);

    for (unsigned int f : cell->face_indices()) {
      auto face = cell->face(f);
      if (!face->at_boundary()) {
        continue;
      }

      fe_face_values.reinit(cell, f);
      if (fe_face_values.get_normal_vectors()[0][2] < 0) {
        continue;
      }

      dealii::Tensor<1, 3> r = face->center() - source;
      for (unsigned int q_index : fe_face_values.quadrature_point_indices()) {
        dealii::Tensor<1, 3> n = fe_face_values.normal_vector(q_index);
        double foo = sigma * dealii::scalar_product(r, n) / (r.norm() * n.norm() * r.norm());
        for (unsigned int i : fe_face_values.dof_indices()) {
          for (unsigned int j : fe_face_values.dof_indices()) {
            cell_matrix(i, j) += (foo * fe_face_values.shape_value(i, q_index) * fe_face_values.shape_value(j, q_index) *
                                  fe_face_values.JxW(q_index));
          }
        }
      }
    }

    for (const unsigned int i : fe_values.dof_indices())
      for (const unsigned int j : fe_values.dof_indices())
        system_matrix.add(local_dof_indices[i], local_dof_indices[j], cell_matrix(i, j));
  }

  dealii::VectorTools::create_point_source_vector(dof_handler, source, system_rhs);
}

void DCProblem::solve() {
  dealii::SolverControl solver_control(1000, 1e-6 * system_rhs.l2_norm());
  dealii::SolverCG<dealii::Vector<double>> solver(solver_control);
  solver.solve(system_matrix, solution, system_rhs, dealii::PreconditionIdentity());
}

void DCProblem::output_results() const {
  dealii::Vector<double> rho(triangulation.n_active_cells());
  for (auto cell: triangulation.active_cell_iterators()) {
    rho[cell->active_cell_index()] = this->rho[cell->material_id()];
  }

  dealii::DataOut<3> data_out;
  data_out.attach_dof_handler(dof_handler);
  data_out.add_data_vector(solution, "solution");
  data_out.add_data_vector(rho, "rho");
  data_out.build_patches();

  std::ofstream output("solution.vtk");
  data_out.write_vtk(output);

  std::vector<double> sites = {0.1, 0.2, 0.5, 1, 2, 5, 10, 20, 30, 40, 50, 60, 80, 100};
  std::vector<double> u(sites.size());

  for (int i = 0; i < (int)sites.size(); ++i) {
    u[i] = dealii::VectorTools::point_value(dof_handler, solution, dealii::Point<3>(sites[i], 0, 0));
  }

  for (int i = 0; i < (int)sites.size(); ++i) {
    std::cout << sites[i] << " " << u[i] << std::endl;
  }
}

void DCProblem::run() {
  make_grid();
  setup_system();
  assemble_system();
  solve();
  output_results();
}

int main() {
  DCProblem dc;
  dc.run();

  return 0;
}
